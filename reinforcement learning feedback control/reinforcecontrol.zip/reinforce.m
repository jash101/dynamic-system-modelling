function Kj=reinforce(t,y)

A=[-Re/L 0 -(N*Kt*fie)/L; 0 0 N; (Kt*fie)/L 0 0];
B=[1;0;0];
T=10;
P=eye(3,3,T);
Q=eye(3,3);
r=1;
Kj=eye(3,3);

for i=1:1:10;
   
    P(:,:,i+1)=(A-B*Kj)'*P(:,:,i)*(A-B*Kj)+Q+Kj'*R*Kj;
end
Kj=inv((R+B'*P(:,:,T)*B))*B'*P(:,:,T)*A;

end