t=0:0.01:10;
Y=zeros(3,1);
Re=8;
L=6;
J=0.02;
B=0;
Kt=1;
Kb=1;
Tl=1;
N=2;
options = odeset('OutputFcn', @odeplot);
[Mt, My] = ode45(@reinforce, t, Y, options);
%plot mt, my
plot (Mt, My(:,1) );
plot (Mt, My(:,2) );