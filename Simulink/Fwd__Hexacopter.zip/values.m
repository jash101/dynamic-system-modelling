Jxx=7.5*exp(-3)
Jyy=7.5*exp(-3)
Jzz=1.3*exp(-2)
kftx=1.5
kfty=0.1
kftz=1.9
Kfax=0.1
Kfay=0.1
Kfaz=0.15
b=3.13*exp(-5)
d=7.5*exp(-7)
Jr=6*exp(-5)
ki=1
kd=0.1
kp=1000
m=5
g=9.81
l=1



